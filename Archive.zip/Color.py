from enum import Enum

class Color(Enum):
    BLACK = 0
    WHITE = 1